package controller;

import java.awt.event.InputEvent;
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import model.SigninDAO;

public class ServletSignin extends HttpServlet
{
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		request.setCharacterEncoding("UTF-8");

		SigninDAO dao = new SigninDAO();
		response.setContentType("text/html; charset=UTF-8");
		PrintWriter out=response.getWriter();
		
		if (dao.signIn(request.getParameter("InputEmail"), request.getParameter("InputPassword")))
		{
			HttpSession httpSession = request.getSession();
			httpSession.setAttribute("sessionKey", request.getParameter("InputEmail"));
			
			
			out.println("<script>alert('로그인 성공');");
			out.println("location.href='index.jsp';");
			out.println("</script>");
			//response.sendRedirect("index.jsp");
		} else
		{
			
			out.println("<script>alert('로그인 실패');");
			out.println("location.href='signin.jsp';");
			out.println("</script>");
			//response.sendRedirect("signin.jsp");
		}
	}
}