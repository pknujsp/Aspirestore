package controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.SignupDAO;
import model.SignupDTO;

public class ServletSignup extends HttpServlet
{

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		request.setCharacterEncoding("UTF-8");

		String id = request.getParameter("InputEmail");
		String password = request.getParameter("InputPassword");
		String name = request.getParameter("InputName");
		String nickname = request.getParameter("InputNickName");
		String birthdate = request.getParameter("SetBirthdate");
		String phone = request.getParameter("InputPhoneNumber");
		String gender = request.getParameter("InputGender");

		SignupDTO information = new SignupDTO(id, password, name, nickname, birthdate, phone, gender);

		SignupDAO dao = new SignupDAO();
		dao.insertNewUser(information);

		response.sendRedirect("index.jsp");
	}
}
