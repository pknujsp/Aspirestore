package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import util.DBConnectionMgr;

public class SigninDAO
{
	private DBConnectionMgr pool;

	public SigninDAO()
	{
		try
		{
			pool = DBConnectionMgr.getInstance();
		} catch (Exception e)
		{
			e.printStackTrace();
		}
	}

	public boolean signIn(String email, String password)
	{
		Connection connection = null;
		PreparedStatement prstmt = null;
		ResultSet set = null;
		boolean flag = false;

		try
		{
			connection = pool.getConnection();
			String query = "SELECT COUNT(user_id) FROM tblmember WHERE user_id=? AND user_password=password(password(?))";
			prstmt = connection.prepareStatement(query);

			prstmt.setString(1, email);
			prstmt.setString(2, password);

			set = prstmt.executeQuery();
			set.next();
			if (set.getInt(1) == 1)
			{
				flag = true;
			}

		} catch (Exception e)
		{
			e.printStackTrace();
		} finally
		{
			pool.freeConnection(connection, prstmt, set);
		}

		return flag;
	}
}